var interface_a_map_navi_config =
[
    [ "appName", "interface_a_map_navi_config.html#acbd9a538111629aa4e0efefc7234cd66", null ],
    [ "appScheme", "interface_a_map_navi_config.html#aa8a4842702bbf8a252f99f716c5ca1f2", null ],
    [ "destination", "interface_a_map_navi_config.html#aa63e0ae247f62d5b4b36ba8d9913cbc1", null ],
    [ "strategy", "interface_a_map_navi_config.html#afabf3caeeb8550f1931941cce99c72d4", null ]
];