var interface_a_map_services =
[
    [ "apiKey", "interface_a_map_services.html#a17e1244c7f0bb6d61c9aa742b167af7f", null ],
    [ "crashReportEnabled", "interface_a_map_services.html#a3bce93f2adfb97061a73e0e9032a2368", null ],
    [ "enableHTTPS", "interface_a_map_services.html#af20172312a8a419cbcd2b28b3082918c", null ]
];