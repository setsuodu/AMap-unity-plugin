var interface_a_map_location_polygon_region =
[
    [ "initWithCoordinates:count:identifier:", "interface_a_map_location_polygon_region.html#a7b58e9529b6616626da5cd82797d4728", null ],
    [ "coordinates", "interface_a_map_location_polygon_region.html#a466934ded6c3f814989a3b5d728b5691", null ],
    [ "count", "interface_a_map_location_polygon_region.html#ac8f866676828b7a375ef86598da652ad", null ]
];