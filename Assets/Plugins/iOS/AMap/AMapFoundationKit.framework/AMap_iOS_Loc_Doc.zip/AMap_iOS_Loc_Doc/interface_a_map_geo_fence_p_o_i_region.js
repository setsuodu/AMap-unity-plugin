var interface_a_map_geo_fence_p_o_i_region =
[
    [ "POIItem", "interface_a_map_geo_fence_p_o_i_region.html#a77b2b37e51877ead0edc696b9aae8566", null ]
];