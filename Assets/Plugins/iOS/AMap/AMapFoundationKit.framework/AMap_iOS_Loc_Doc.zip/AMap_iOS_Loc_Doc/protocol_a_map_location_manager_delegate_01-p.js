var protocol_a_map_location_manager_delegate_01_p =
[
    [ "amapLocationManager:didChangeAuthorizationStatus:", "protocol_a_map_location_manager_delegate_01-p.html#ac9ce3b0c38e08ef4fd9cffd9dd4d01bd", null ],
    [ "amapLocationManager:didDetermineState:forRegion:", "protocol_a_map_location_manager_delegate_01-p.html#aa0676c955511faaf94c8f9135460a652", null ],
    [ "amapLocationManager:didEnterRegion:", "protocol_a_map_location_manager_delegate_01-p.html#ae4fc6080534b574ff2b4dd197deb4d4c", null ],
    [ "amapLocationManager:didExitRegion:", "protocol_a_map_location_manager_delegate_01-p.html#a215f516e0f1041bfbd47101b89ef48b3", null ],
    [ "amapLocationManager:didFailWithError:", "protocol_a_map_location_manager_delegate_01-p.html#a6c84396a5b2d5216be5f5a65b369abe2", null ],
    [ "amapLocationManager:didStartMonitoringForRegion:", "protocol_a_map_location_manager_delegate_01-p.html#a9f43337ef5c983e81a0d8c9ed3740af0", null ],
    [ "amapLocationManager:didUpdateHeading:", "protocol_a_map_location_manager_delegate_01-p.html#a75c8b1b9bdb7a729716680c4b4b83ea5", null ],
    [ "amapLocationManager:didUpdateLocation:", "protocol_a_map_location_manager_delegate_01-p.html#a314c13ad02f2d4b5e5230d897d282e55", null ],
    [ "amapLocationManager:didUpdateLocation:reGeocode:", "protocol_a_map_location_manager_delegate_01-p.html#ab20f5e1f59c242ad5f53efe7099f1653", null ],
    [ "amapLocationManager:monitoringDidFailForRegion:withError:", "protocol_a_map_location_manager_delegate_01-p.html#a683eeb91ed3cb6b0dda4f7fbb7da6b95", null ],
    [ "amapLocationManagerShouldDisplayHeadingCalibration:", "protocol_a_map_location_manager_delegate_01-p.html#a3a855b8ccc7288b1232d75f1c7720ce1", null ]
];