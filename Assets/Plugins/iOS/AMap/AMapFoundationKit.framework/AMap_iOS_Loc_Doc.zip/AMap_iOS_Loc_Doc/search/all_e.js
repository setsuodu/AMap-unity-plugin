var searchData=
[
  ['tel',['tel',['../interface_a_map_location_p_o_i_item.html#a582d6e5e4b33f3b75bbd6f1d73fdfe37',1,'AMapLocationPOIItem']]],
  ['type',['type',['../interface_a_map_location_p_o_i_item.html#a3592cdc16de200c8f8854915adf1b0da',1,'AMapLocationPOIItem']]],
  ['typecode',['typeCode',['../interface_a_map_location_p_o_i_item.html#a9378d14e63ef6aaa20bc24ac852e60f5',1,'AMapLocationPOIItem']]]
];
