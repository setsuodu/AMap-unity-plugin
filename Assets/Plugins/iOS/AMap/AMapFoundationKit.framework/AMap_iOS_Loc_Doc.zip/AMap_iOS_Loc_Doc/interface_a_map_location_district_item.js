var interface_a_map_location_district_item =
[
    [ "cityCode", "interface_a_map_location_district_item.html#a68faf0fee6f194b05ef302361e7a2ebb", null ],
    [ "district", "interface_a_map_location_district_item.html#a8d14473aed3c39dc735ebb47770eb24d", null ],
    [ "districtCode", "interface_a_map_location_district_item.html#a87ac12e5ba47351a413df2b2f1e06e42", null ],
    [ "polylinePoints", "interface_a_map_location_district_item.html#a602881653df678bf044195464b5f992b", null ]
];