//
//  officialDemoLoc-Swift-Bridging-Header.h
//  officialDemoLoc
//
//  Created by 刘博 on 7/11/16.
//  Copyright © 2016年 AutoNavi. All rights reserved.
//

#ifndef officialDemoLoc_Swift_Bridging_Header_h
#define officialDemoLoc_Swift_Bridging_Header_h

#import <AMapLocationKit/AMapLocationKit.h>
#import <MAMapKit/MAMapKit.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import "APIKey.h"

#endif /* officialDemoLoc_Swift_Bridging_Header_h */
